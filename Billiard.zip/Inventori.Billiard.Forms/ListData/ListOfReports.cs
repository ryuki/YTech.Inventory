public enum ListOfReports
{
    MItem,
    MGroup,
    MCustomer,
    MSupplier,
    MEmployee,
    MDesk,
    RekapTotalTransactionByItem,
    RekapTotalTransactionByDesk,
    ReportDetailTransaction,
    ReportRekapKomisiWasit,
    ReportListTransaction,
    ReportStokCard,
    MDepartment,
    ReportListTransactionDetail,
    ReportListTransactionDetailItem
}
