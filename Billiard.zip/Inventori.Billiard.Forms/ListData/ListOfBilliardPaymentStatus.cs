public enum ListOfBilliardPaymentStatus
{
    None,
    Booking,
    In,
    Out,
    Paid
}
