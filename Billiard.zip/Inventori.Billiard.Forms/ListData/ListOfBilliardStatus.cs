public enum ListOfBilliardStatus
{
    VIP,
    Active,
    Mini,
    Off
}

