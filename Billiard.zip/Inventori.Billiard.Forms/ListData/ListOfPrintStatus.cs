public enum ListOfPrintStatus
{
    PrintOK,
    PrintFailed,
    PrintCancel
}
