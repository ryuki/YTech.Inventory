using System;
using System.Collections.Generic;
using System.Text;

namespace Inventori.Billiard.Data
{
    public class Class1
    {
    }
}
